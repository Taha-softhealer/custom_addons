# -*- coding: utf-8 -*-
# Part of Softhealer Technologies. See LICENSE file for full copyright and licensing details.

from . import sh_automatic_workflow
from . import res_config_setting
from . import sale_order_inherit
from . import res_partner_inherit
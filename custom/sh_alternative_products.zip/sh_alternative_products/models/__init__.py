# -*- coding: utf-8 -*-
# Part of Softhealer Technologies. See LICENSE file for full copyright and licensing details.

from . import sh_product_inherit
from . import sh_sale_order_line_inherit
from . import sh_replace_product